# Overview

timer for predicting the rate of things.

put within paulroth3d.github.io
