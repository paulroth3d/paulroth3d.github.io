import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './styles/global.css'
import './styles/components.css'

import { StopwatchDisplay } from './web-components/StopwatchDisplay.js'
import { SampleList } from './web-components/SampleList.js'
import { PredictionDisplay } from './web-components/PredictionDisplay.js'

if (!customElements.get('stopwatch-display')) customElements.define('stopwatch-display', StopwatchDisplay)
if (!customElements.get('sample-list'))        customElements.define('sample-list', SampleList)
if (!customElements.get('prediction-display')) customElements.define('prediction-display', PredictionDisplay)

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
