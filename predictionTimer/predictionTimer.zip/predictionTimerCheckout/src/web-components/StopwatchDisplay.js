import { formatDurationPrecise } from '../lib/timeUtils.js'

export class StopwatchDisplay extends HTMLElement {
  static observedAttributes = ['elapsed']

  constructor() {
    super()
    this._elapsed = 0
    const shadow = this.attachShadow({ mode: 'open' })

    const style = document.createElement('style')
    style.textContent = `
      :host {
        display: block;
        font-family: 'JetBrains Mono', 'Fira Code', ui-monospace, monospace;
      }
      .timer {
        font-size: clamp(3rem, 12vw, 5.5rem);
        font-weight: 600;
        letter-spacing: -0.02em;
        color: #e2e8f0;
        line-height: 1;
        user-select: none;
      }
      .timer.running {
        color: #22d3ee;
      }
      .ms {
        font-size: 0.35em;
        opacity: 0.55;
        vertical-align: baseline;
      }
    `

    this._timerEl = document.createElement('div')
    this._timerEl.className = 'timer'
    this._timerEl.textContent = '00:00'

    shadow.appendChild(style)
    shadow.appendChild(this._timerEl)
  }

  attributeChangedCallback(name, _old, newVal) {
    if (name === 'elapsed') this._update(parseFloat(newVal) || 0)
  }

  set elapsed(val) {
    this._update(val)
  }

  set running(val) {
    if (val) {
      this._timerEl.classList.add('running')
    } else {
      this._timerEl.classList.remove('running')
    }
  }

  _update(seconds) {
    this._elapsed = seconds
    const formatted = formatDurationPrecise(seconds)
    // Split on the dot to separate seconds from milliseconds
    const [mainTime, ms] = formatted.split('.')
    this._timerEl.innerHTML = ms
      ? `${mainTime}.<span class="ms">${ms}</span>`
      : mainTime
  }
}
