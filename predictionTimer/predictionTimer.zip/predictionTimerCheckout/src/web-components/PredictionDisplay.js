import { formatDuration, formatCostPerRecord } from '../lib/timeUtils.js'

export class PredictionDisplay extends HTMLElement {
  static observedAttributes = ['remaining-records', 'avg-cost']

  constructor() {
    super()
    this._remainingRecords = 0
    this._avgCost = 0
  }

  connectedCallback() {
    this._render()
  }

  attributeChangedCallback(name, _old, newVal) {
    if (name === 'remaining-records') this._remainingRecords = parseFloat(newVal) || 0
    if (name === 'avg-cost') this._avgCost = parseFloat(newVal) || 0
    this._render()
  }

  set remainingRecords(val) {
    this._remainingRecords = val || 0
    this._render()
  }

  set avgCost(val) {
    this._avgCost = val || 0
    this._render()
  }

  _render() {
    const r = this._remainingRecords
    const c = this._avgCost
    const valid = r > 0 && c > 0 && isFinite(c)
    const predicted = valid ? r * c : 0

    this.innerHTML = `
      <div class="prediction-grid">
        <div class="prediction-stat">
          <span class="prediction-label">Remaining Records</span>
          <span class="prediction-value">${valid ? r.toLocaleString() : '--'}</span>
        </div>
        <div class="prediction-stat">
          <span class="prediction-label">Avg Time / Record</span>
          <span class="prediction-value">${valid ? formatCostPerRecord(c) : '--'}</span>
        </div>
        <div class="prediction-stat prediction-stat--featured">
          <span class="prediction-label">Predicted Time Remaining</span>
          <span class="prediction-value prediction-value--large">${valid ? formatDuration(predicted) : '--'}</span>
        </div>
      </div>
    `
  }
}
