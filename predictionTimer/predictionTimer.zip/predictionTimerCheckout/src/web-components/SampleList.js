import { formatDurationWithMs, formatCostPerRecord } from '../lib/timeUtils.js'

export class SampleList extends HTMLElement {
  static observedAttributes = ['samples']

  constructor() {
    super()
    this._samples = []
  }

  connectedCallback() {
    this._render()
  }

  attributeChangedCallback(name, _old, newVal) {
    if (name === 'samples' && newVal) {
      try {
        this._samples = JSON.parse(newVal)
      } catch {
        this._samples = []
      }
      this._render()
    }
  }

  set samples(val) {
    this._samples = Array.isArray(val) ? val : []
    this._render()
  }

  _render() {
    const samples = this._samples

    if (!samples.length) {
      this.innerHTML = ''
      return
    }

    const rows = samples.map((s) => {
      const costPerRec = s.records > 0 ? s.duration / s.records : 0
      return `
        <tr>
          <td>${formatDurationWithMs(s.duration)}</td>
          <td>${s.records.toLocaleString()}</td>
          <td>${formatCostPerRecord(costPerRec)}</td>
          <td>
            <button
              class="btn-danger delete-btn"
              data-id="${s.id}"
              aria-label="Delete sample"
            >✕</button>
          </td>
        </tr>
      `
    }).join('')

    // Calculate metrics
    const totalDuration = samples.reduce((sum, s) => sum + s.duration, 0)
    const totalRecords = samples.reduce((sum, s) => sum + s.records, 0)
    const avgCostPerRecord = totalRecords > 0 ? totalDuration / totalRecords : 0

    const metricsRow = `
      <tr class="metrics-row">
        <td><strong>${formatDurationWithMs(totalDuration)}</strong></td>
        <td><strong>${totalRecords.toLocaleString()}</strong></td>
        <td><strong>${formatCostPerRecord(avgCostPerRecord)}</strong></td>
        <td></td>
      </tr>
    `

    this.innerHTML = `
      <table class="sample-table">
        <thead>
          <tr>
            <th>Duration</th>
            <th>Records</th>
            <th>Cost / rec</th>
            <th></th>
          </tr>
        </thead>
        <tbody>${rows}${metricsRow}</tbody>
      </table>
    `

    this.querySelectorAll('.delete-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.dataset.id
        this.dispatchEvent(new CustomEvent('delete-sample', {
          bubbles: true,
          composed: true,
          detail: { id },
        }))
      })
    })
  }
}
