import '../styles/tabs.css'

export default function TabSwitcher({ activeMode, onSwitch }) {
  return (
    <nav className="tab-switcher" role="tablist">
      <button
        role="tab"
        aria-selected={activeMode === 'stopwatch'}
        className={activeMode === 'stopwatch' ? 'active' : ''}
        onClick={() => onSwitch('stopwatch')}
      >
        <span className="tab-icon">⏱</span>
        Stopwatch
      </button>
      <button
        role="tab"
        aria-selected={activeMode === 'calculator'}
        className={activeMode === 'calculator' ? 'active' : ''}
        onClick={() => onSwitch('calculator')}
      >
        <span className="tab-icon">📊</span>
        Calculator
      </button>
    </nav>
  )
}
