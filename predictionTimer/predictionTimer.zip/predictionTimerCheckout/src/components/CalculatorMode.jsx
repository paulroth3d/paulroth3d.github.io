import { useState, useRef, useEffect } from 'react'
import { computePrediction } from '../lib/timeUtils.js'
import '../styles/calculator.css'

export default function CalculatorMode({ samples, hidden }) {
  const [totalRecords, setTotalRecords] = useState('')
  const [processedRecords, setProcessedRecords] = useState('')

  const sampleListRef = useRef(null)
  const predictionRef = useRef(null)

  useEffect(() => {
    const el = sampleListRef.current
    if (el) el.samples = samples
  }, [samples])

  const total = parseInt(totalRecords, 10) || 0
  const processed = parseInt(processedRecords, 10) || 0

  const inputsProvided = totalRecords !== '' && processedRecords !== ''
  const inputsValid = total > 0 && processed >= 0 && processed < total

  const prediction = inputsProvided && inputsValid
    ? computePrediction({ samples, totalRecords: total, processedRecords: processed })
    : null

  useEffect(() => {
    const el = predictionRef.current
    console.log('PredictionDisplay ref:', el, 'prediction:', prediction)
    if (!el) return
    if (prediction) {
      el.remainingRecords = prediction.remainingRecords
      el.avgCost = prediction.avgCostPerRecord
    } else {
      el.remainingRecords = 0
      el.avgCost = 0
    }
  }, [prediction])

  const showInvalidMsg = inputsProvided && !inputsValid
  const showNoSamplesMsg = samples.length === 0

  return (
    <div className="calculator-mode" style={{ display: hidden ? 'none' : 'flex' }}>
      <div className="card">
        <div className="calculator-inputs">
          <div>
            <label htmlFor="total-records">Total Records</label>
            <input
              id="total-records"
              type="number"
              min="1"
              placeholder="e.g. 10000"
              value={totalRecords}
              onChange={(e) => setTotalRecords(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="processed-records">Records Already Processed</label>
            <input
              id="processed-records"
              type="number"
              min="0"
              placeholder="e.g. 2500"
              value={processedRecords}
              onChange={(e) => setProcessedRecords(e.target.value)}
            />
          </div>
        </div>
      </div>

      {samples.length > 0 && (
        <div className="card prediction-card">
          <p className="prediction-card-title">Prediction</p>
          {showInvalidMsg ? (
            <div className="calculator-invalid">
              {total <= 0
                ? 'Total records must be greater than 0.'
                : processed >= total
                ? 'Records already processed must be less than the total.'
                : 'Please enter valid record counts.'}
            </div>
          ) : (
            <prediction-display ref={predictionRef} remaining-records="0" avg-cost="0" />
          )}
        </div>
      )}

      <div>
        <p className="samples-section-title">
          Samples ({samples.length})
        </p>
        {samples.length === 0 ? (
          <div className="card empty-samples">
            No samples yet — use the Stopwatch tab to record timing samples.
          </div>
        ) : (
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <sample-list ref={sampleListRef} />
          </div>
        )}
      </div>
    </div>
  )
}
