import { useState, useRef, useEffect, useCallback } from 'react'
import '../styles/stopwatch.css'

export default function StopwatchMode({ samples, dispatch, hidden }) {
  const [status, setStatus] = useState('idle')
  const [elapsed, setElapsed] = useState(0)
  const [pendingDuration, setPendingDuration] = useState(null)
  const [recordCount, setRecordCount] = useState('')

  const rafRef = useRef(null)
  const startTimeRef = useRef(null)
  const displayRef = useRef(null)

  const tick = useCallback(() => {
    const e = (Date.now() - startTimeRef.current) / 1000
    setElapsed(e)
    if (displayRef.current) {
      displayRef.current.elapsed = e
      displayRef.current.running = true
    }
    rafRef.current = requestAnimationFrame(tick)
  }, [])

  useEffect(() => {
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [])

  useEffect(() => {
    if (displayRef.current) {
      displayRef.current.running = status === 'running'
    }
  }, [status])

  const handleStart = () => {
    startTimeRef.current = Date.now()
    setStatus('running')
    setElapsed(0)
    if (displayRef.current) {
      displayRef.current.elapsed = 0
      displayRef.current.running = true
    }
    rafRef.current = requestAnimationFrame(tick)
  }

  const handleStop = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    const final = (Date.now() - startTimeRef.current) / 1000
    setStatus('stopped')
    setElapsed(final)
    setPendingDuration(final)
    if (displayRef.current) {
      displayRef.current.elapsed = final
      displayRef.current.running = false
    }
  }

  const handleSave = () => {
    const count = parseInt(recordCount, 10)
    if (!count || count <= 0) return
    dispatch({
      type: 'ADD_SAMPLE',
      payload: { duration: pendingDuration, records: count },
    })
    resetState()
  }

  const handleDiscard = () => resetState()

  const handleReset = () => resetState()

  const resetState = () => {
    setStatus('idle')
    setElapsed(0)
    setPendingDuration(null)
    setRecordCount('')
    if (displayRef.current) {
      displayRef.current.elapsed = 0
      displayRef.current.running = false
    }
  }

  const sampleListRef = useRef(null)
  useEffect(() => {
    const el = sampleListRef.current
    if (el) el.samples = samples
  }, [samples])

  return (
    <div className="stopwatch-mode" style={{ display: hidden ? 'none' : 'flex' }}>
      <div className="card stopwatch-card">
        <span className={`stopwatch-status ${status}`}>
          {status === 'idle' && 'Ready'}
          {status === 'running' && 'Recording'}
          {status === 'stopped' && 'Stopped'}
        </span>

        <stopwatch-display ref={displayRef} elapsed="0" />

        <div className="stopwatch-controls">
          {status === 'idle' && (
            <button className="btn-primary" onClick={handleStart}>
              Start
            </button>
          )}
          {status === 'running' && (
            <button className="btn-danger" onClick={handleStop}>
              Stop
            </button>
          )}
          {status === 'stopped' && (
            <button className="btn-ghost" onClick={handleDiscard}>
              Discard
            </button>
          )}
          {status === 'stopped' && elapsed === 0 && (
            <button className="btn-ghost" onClick={handleReset}>
              Reset
            </button>
          )}
        </div>

        {status === 'stopped' && (
          <div className="record-form">
            <p className="record-form-title">How many records were processed?</p>
            <label htmlFor="record-count">Record Count</label>
            <input
              id="record-count"
              type="number"
              min="1"
              placeholder="e.g. 500"
              value={recordCount}
              onChange={(e) => setRecordCount(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              autoFocus
            />
            <div className="record-form-actions">
              <button
                className="btn-primary"
                onClick={handleSave}
                disabled={!recordCount || parseInt(recordCount, 10) <= 0}
              >
                Save Sample
              </button>
              <button className="btn-ghost" onClick={handleDiscard}>
                Discard
              </button>
            </div>
          </div>
        )}
      </div>

      <div>
        <p className="samples-section-title">
          Samples ({samples.length})
        </p>
        {samples.length === 0 ? (
          <div className="card empty-samples">
            No samples yet — start the stopwatch to record your first sample.
          </div>
        ) : (
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <sample-list ref={sampleListRef} />
          </div>
        )}
      </div>
    </div>
  )
}
