import { useReducer, useEffect, useRef } from 'react'
import TabSwitcher from './components/TabSwitcher.jsx'
import StopwatchMode from './components/StopwatchMode.jsx'
import CalculatorMode from './components/CalculatorMode.jsx'
import './styles/app.css'

function reducer(state, action) {
  switch (action.type) {
    case 'SET_MODE':
      return { ...state, mode: action.payload.mode }
    case 'ADD_SAMPLE':
      return {
        ...state,
        samples: [
          ...state.samples,
          {
            id: crypto.randomUUID(),
            duration: action.payload.duration,
            records: action.payload.records,
          },
        ],
      }
    case 'DELETE_SAMPLE':
      return {
        ...state,
        samples: state.samples.filter((s) => s.id !== action.payload.id),
      }
    default:
      return state
  }
}

function init() {
  try {
    const saved = localStorage.getItem('pt-samples')
    return { mode: 'stopwatch', samples: saved ? JSON.parse(saved) : [] }
  } catch {
    return { mode: 'stopwatch', samples: [] }
  }
}

export default function App() {
  const [state, dispatch] = useReducer(reducer, undefined, init)
  const appRef = useRef(null)

  useEffect(() => {
    localStorage.setItem('pt-samples', JSON.stringify(state.samples))
  }, [state.samples])

  useEffect(() => {
    const el = appRef.current
    if (!el) return
    const handler = (e) => {
      if (e.type === 'delete-sample') {
        dispatch({ type: 'DELETE_SAMPLE', payload: { id: e.detail.id } })
      }
    }
    el.addEventListener('delete-sample', handler)
    return () => el.removeEventListener('delete-sample', handler)
  }, [])

  return (
    <div className="app" ref={appRef}>
      <header className="app-header">
        <h1 className="app-title">Prediction Timer</h1>
        <p className="app-subtitle">Estimate remaining time from sampled data</p>
      </header>

      <main className="app-main">
        <TabSwitcher
          activeMode={state.mode}
          onSwitch={(mode) => dispatch({ type: 'SET_MODE', payload: { mode } })}
        />

        <StopwatchMode
          samples={state.samples}
          dispatch={dispatch}
          hidden={state.mode !== 'stopwatch'}
        />

        <CalculatorMode
          samples={state.samples}
          dispatch={dispatch}
          hidden={state.mode !== 'calculator'}
        />
      </main>
    </div>
  )
}
