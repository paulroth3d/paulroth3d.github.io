# Prediction Timer — Implementation Plan

## Context

Build a standalone static webpage (React + Vite) that predicts how long a batch process will take based on user-captured timing samples. The project is a fresh empty git repo — everything is created from scratch.

The app solves this problem: given N samples of (duration, record count), compute the average time per record, then multiply by remaining records to predict total time remaining.

---

## Architecture

**Tech stack**: React 19 (Vite scaffold), Web Components as leaf display nodes, plain CSS with custom properties, localStorage persistence. No router, no external state library.

**Web Component strategy**: React owns all state and logic. Web Components are pure display leaves — React passes data down as properties/attributes; WCs fire custom DOM events back up. Shadow DOM only for `<stopwatch-display>` (the timer face); the other two WCs use open DOM so they inherit CSS variables from the document.

**Tab switching**: Both mode components stay mounted; CSS `display: none` hides the inactive one. This preserves a running stopwatch when the user switches to Calculator mode.

---

## File Structure

```
predictionTimer/
├── index.html
├── vite.config.js
├── package.json
└── src/
    ├── main.jsx                        # Entry point; registers all 3 WCs
    ├── App.jsx                         # useReducer state, localStorage sync, tab routing
    ├── components/
    │   ├── TabSwitcher.jsx
    │   ├── StopwatchMode.jsx           # rAF timer, pending-record form
    │   └── CalculatorMode.jsx          # inputs + prediction output
    ├── web-components/
    │   ├── StopwatchDisplay.js         # <stopwatch-display> — shadow DOM timer face
    │   ├── SampleList.js               # <sample-list> — table, fires delete-sample events
    │   └── PredictionDisplay.js        # <prediction-display> — formatted prediction output
    ├── lib/
    │   └── timeUtils.js                # Pure: formatDuration, formatCostPerRecord, computePrediction
    └── styles/
        ├── global.css                  # CSS variables (dark theme), reset, typography
        ├── tabs.css
        ├── stopwatch.css
        └── calculator.css
```

---

## Data Model

```js
// Sample
{ id: string, duration: number /* seconds */, records: number }

// App state (useReducer)
{ mode: 'stopwatch' | 'calculator', samples: Sample[] }

// Actions
ADD_SAMPLE    // payload: { duration, records }
DELETE_SAMPLE // payload: { id }
SET_MODE      // payload: { mode }

// Stopwatch local state (useState in StopwatchMode)
{ status: 'idle'|'running'|'stopped', startTime: number|null, elapsed: number, pendingDuration: number|null }
```

Persistence: `useEffect` in `App.jsx` writes samples to `localStorage('pt-samples')` on every change; re-hydrated via lazy initializer on mount.

---

## Key Logic

### `lib/timeUtils.js`

```js
formatDuration(seconds)        // 3661 → "1h 1m 1s", 75 → "1m 15s", 45 → "45s"
formatCostPerRecord(sec)       // 0.35 → "0.35s/rec", 90 → "1m 30s/rec"
computePrediction({ samples, totalRecords, processedRecords })
  // → { remainingRecords, avgCostPerRecord, predictedTimeSeconds } | null
  // avgCostPerRecord = sum(durations) / sum(records) across all samples
  // predicted = remainingRecords × avgCostPerRecord
```

### Stopwatch timer (`StopwatchMode.jsx`)

`requestAnimationFrame` loop reading `Date.now() - startTimeRef.current` for accuracy. On Stop: freeze display, show record-count form. Save → `ADD_SAMPLE`, reset. Discard → reset only.

### `<stopwatch-display>`

Shadow DOM. Observes `elapsed` attribute + property setter. Renders large monospaced HH:MM:SS display.

### `<sample-list>`

Open DOM. Accepts `samples` as JSON attribute or direct property. Renders table (Duration | Records | Cost/rec | Delete). Delete button fires `new CustomEvent('delete-sample', { bubbles: true, composed: true, detail: { id } })`. App.jsx listens on a wrapper ref.

### `<prediction-display>`

Open DOM. Accepts `remaining-records` + `avg-cost` attributes/properties. Renders formatted prediction block; shows `--` placeholder when values are invalid.

---

## CSS Theme (Dark)

```
--color-bg: #0f1117         --color-surface: #1a1d27
--color-accent: #22d3ee     --color-danger: #f87171
--font-sans: Inter           --font-mono: JetBrains Mono
```

---

## Implementation Order

1. Scaffold: `npm create vite@latest . -- --template react`, remove boilerplate
2. `lib/timeUtils.js` — pure functions
3. `styles/global.css` — variables, reset
4. Web Component stubs → register in `main.jsx`, verify React renders them
5. `App.jsx` + `TabSwitcher.jsx` — reducer, localStorage, tab switching
6. `StopwatchMode.jsx` — full stopwatch + ADD_SAMPLE + `<stopwatch-display>`
7. `CalculatorMode.jsx` — inputs, validation, `<prediction-display>`
8. `SampleList.js` (full) + delete event wiring in `App.jsx`
9. `StopwatchDisplay.js` (full shadow DOM styling)
10. CSS polish (tabs, stopwatch, calculator layouts)

---

## Verification

- `npm run dev` starts without errors; `npm run build` produces clean `dist/`
- Stopwatch: Start → live tick → Stop → record form → Save → sample in list
- Stopwatch: Stop → Discard → clean reset, no sample added
- Calculator: total=1000, processed=0, sample 10s/100rec → prediction = 1m 40s
- Calculator: total=1000, processed=500, same sample → prediction = 50s
- Delete sample → list updates, prediction recalculates
- Refresh page → samples survive (localStorage)
- Switch tabs mid-stopwatch-run → timer keeps running
- Invalid state (processed ≥ total) → error message shown, no prediction

---

## Millisecond Precision Enhancement Plan

### Problem
The stopwatch currently tracks and displays time only to the second, rounding durations when saving samples. This loses precision for short-duration samples where milliseconds matter.

### Current State Analysis

**Timing mechanism** ([StopwatchMode.jsx:14-22](src/components/StopwatchMode.jsx#L14-L22)):
- Already captures milliseconds via `Date.now()` and stores as fractional seconds
- `tick()` function: `elapsed = (Date.now() - startTimeRef.current) / 1000`
- ✅ No changes needed here

**Display** ([StopwatchDisplay.js:59-62](src/web-components/StopwatchDisplay.js#L59-L62)):
- Already uses `formatDurationPrecise()` which shows MM:SS or H:MM:SS
- ❌ Missing milliseconds in display

**Data storage** ([StopwatchMode.jsx:64](src/components/StopwatchMode.jsx#L64)):
- Rounds to 1 decimal place: `Math.round(pendingDuration * 10) / 10`
- ❌ Loses precision; need to store full milliseconds

**Data model** ([PLAN.md:54](PLAN.md#L54)):
- Schema: `{ id: string, duration: number /* seconds */, records: number }`
- Duration stored in seconds as floating-point
- ✅ Can already hold millisecond precision

**Sample list display** ([SampleList.js:40](src/web-components/SampleList.js#L40)):
- Uses `formatDuration()` which rounds to whole seconds
- ❌ Should show milliseconds for sub-minute durations

### Changes Required

#### 1. Update `formatDurationPrecise()` in [timeUtils.js:11-19](src/lib/timeUtils.js#L11-L19)
**Current behavior**: Shows `MM:SS` or `H:MM:SS`  
**New behavior**: Show `MM:SS.mmm` or `H:MM:SS.mmm` with styled milliseconds

```js
// Add milliseconds to display
export function formatDurationPrecise(seconds) {
  const totalMs = Math.abs(seconds) * 1000
  const h = Math.floor(totalMs / 3600000)
  const m = Math.floor((totalMs % 3600000) / 60000)
  const s = Math.floor((totalMs % 60000) / 1000)
  const ms = Math.floor(totalMs % 1000)
  const pad = (n) => String(n).padStart(2, '0')
  const padMs = (n) => String(n).padStart(3, '0')
  
  if (h > 0) return `${h}:${pad(m)}:${pad(s)}.${padMs(ms)}`
  return `${pad(m)}:${pad(s)}.${padMs(ms)}`
}
```

#### 2. Update `StopwatchDisplay.js` shadow DOM styles
**Rationale**: The `.ms` class already exists but needs to be applied to the milliseconds portion

Update `_update()` method to wrap milliseconds in a `<span class="ms">`:
```js
_update(seconds) {
  this._elapsed = seconds
  const formatted = formatDurationPrecise(seconds)
  // Split on the dot to separate seconds from milliseconds
  const [mainTime, ms] = formatted.split('.')
  this._timerEl.innerHTML = ms 
    ? `${mainTime}.<span class="ms">${ms}</span>`
    : mainTime
}
```

#### 3. Remove rounding in [StopwatchMode.jsx:64](src/components/StopwatchMode.jsx#L64)
**Current**: `Math.round(pendingDuration * 10) / 10` → rounds to 0.1s precision  
**New**: `pendingDuration` → stores full millisecond precision

```js
dispatch({
  type: 'ADD_SAMPLE',
  payload: { duration: pendingDuration, records: count },
})
```

#### 4. Create `formatDurationWithMs()` for sample list display
**Purpose**: Show milliseconds in sample list for better precision visibility

Add to [timeUtils.js](src/lib/timeUtils.js):
```js
export function formatDurationWithMs(seconds) {
  const totalMs = Math.abs(seconds) * 1000
  const h = Math.floor(totalMs / 3600000)
  const m = Math.floor((totalMs % 3600000) / 60000)
  const s = Math.floor((totalMs % 60000) / 1000)
  const ms = Math.floor(totalMs % 1000)
  
  // Only show milliseconds for durations < 1 minute
  if (h > 0) return `${h}h ${m}m ${s}s`
  if (m > 0) return `${m}m ${s}s`
  if (s > 0) return `${s}.${String(ms).padStart(3, '0')}s`
  return `${ms}ms`
}
```

#### 5. Update [SampleList.js:40](src/web-components/SampleList.js#L40)
Replace `formatDuration()` with `formatDurationWithMs()`:
```js
<td>${formatDurationWithMs(s.duration)}</td>
```

### Backwards Compatibility

**Existing localStorage data**: Samples stored with rounded durations (e.g., `12.5`) will continue to work correctly. The new precision only applies to newly captured samples.

### Visual Design

- Stopwatch display: milliseconds shown with reduced opacity (`.ms` class at 55% opacity, 35% size)
- Sample list: milliseconds shown inline (e.g., "15.234s" or "45ms") for sub-minute durations
- No milliseconds shown for durations ≥ 1 minute in the sample list (reduces visual clutter)

### Testing Checklist

1. ✅ Start stopwatch → verify milliseconds tick in real-time
2. ✅ Stop at sub-second duration → verify milliseconds preserved in display
3. ✅ Save sample with sub-second duration → verify full precision stored
4. ✅ Sample list shows milliseconds for short durations
5. ✅ Sample list shows standard format (no ms) for long durations
6. ✅ Calculator prediction uses full millisecond precision in calculations
7. ✅ Existing samples in localStorage continue to load and display correctly
8. ✅ Cost per record calculation benefits from millisecond precision

### Implementation Order

1. Update `formatDurationPrecise()` to include milliseconds
2. Update `StopwatchDisplay._update()` to wrap milliseconds in styled span
3. Remove rounding in `StopwatchMode.handleSave()`
4. Add `formatDurationWithMs()` utility function
5. Update `SampleList` to use new formatter
6. Manual testing with dev server
7. Verify localStorage persistence and backwards compatibility
